public static class GameManagerStatic
{
    public static bool IsAiLoaded = false;
    public static string LoadedJsonData = "";
}